
import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, BookOpen, Camera, FileImage } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface UploadScreenProps {
  onFileUpload: (file: File) => Promise<void>;
}

/**
 * Tela inicial com logo e área de upload de imagem
 * Inclui drag & drop e seleção de arquivo tradicional
 */
const UploadScreen: React.FC<UploadScreenProps> = ({ onFileUpload }) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  /**
   * Manipula eventos de drag and drop
   */
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  /**
   * Processa arquivo selecionado via drop
   */
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFileSelection(files[0]);
    }
  };

  /**
   * Processa arquivo selecionado via input
   */
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleFileSelection(files[0]);
    }
  };

  /**
   * Valida e define o arquivo selecionado
   */
  const handleFileSelection = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
    } else {
      alert('Por favor, selecione uma imagem válida (JPG, PNG, HEIC)');
    }
  };

  /**
   * Envia o arquivo selecionado para processamento
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile) {
      alert('Por favor, selecione uma imagem da capa do livro');
      return;
    }

    setIsUploading(true);
    try {
      await onFileUpload(selectedFile);
    } catch (error) {
      console.error('Erro no upload:', error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Header com logo e título */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg"
          >
            <BookOpen className="w-10 h-10 text-white" />
          </motion.div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Summarizer
          </h1>
          <p className="text-lg text-gray-600 max-w-md mx-auto">
            Transforme qualquer livro em um resumo inteligente com o poder da IA
          </p>
        </motion.div>

        {/* Card principal com área de upload */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Área de upload com drag & drop */}
                <div>
                  <label htmlFor="bookImage" className="block text-sm font-semibold text-gray-800 mb-3">
                    Escolha ou tire uma foto da capa do livro:
                  </label>
                  
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`
                      relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 cursor-pointer
                      ${dragActive 
                        ? 'border-blue-500 bg-blue-50 shadow-lg' 
                        : selectedFile 
                          ? 'border-green-500 bg-green-50 shadow-md' 
                          : 'border-gray-300 hover:border-gray-400 hover:shadow-md'
                      }
                    `}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      id="bookImage"
                      name="data"
                      onChange={handleFileInput}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      required
                    />
                    
                    <div className="space-y-4">
                      {selectedFile ? (
                        <motion.div
                          initial={{ scale: 0.8 }}
                          animate={{ scale: 1 }}
                          className="space-y-3"
                        >
                          <Camera className="w-12 h-12 text-green-600 mx-auto" />
                          <p className="text-green-700 font-semibold text-lg">{selectedFile.name}</p>
                          <p className="text-sm text-green-600">Arquivo selecionado com sucesso!</p>
                        </motion.div>
                      ) : (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="space-y-3"
                        >
                          <div className="flex justify-center space-x-2">
                            <Upload className="w-8 h-8 text-gray-400" />
                            <FileImage className="w-8 h-8 text-gray-400" />
                          </div>
                          <p className="text-gray-700 font-medium">
                            Arraste uma imagem aqui ou clique para selecionar
                          </p>
                          <p className="text-sm text-gray-500">
                            Formatos suportados: JPG, PNG, HEIC
                          </p>
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                </div>

                {/* Botão de envio */}
                <motion.div
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                >
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-4 text-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl"
                    disabled={isUploading || !selectedFile}
                  >
                    {isUploading ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="flex items-center"
                      >
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-3" />
                        Enviando...
                      </motion.div>
                    ) : (
                      <>
                        <Upload className="w-5 h-5 mr-3" />
                        Enviar para Resumo
                      </>
                    )}
                  </Button>
                </motion.div>
              </form>

              {/* Rodapé informativo */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="mt-8 pt-6 border-t text-center"
              >
                <p className="text-sm text-gray-500">
                  Seu livro será processado com IA para gerar resumos detalhados e estruturados
                </p>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default UploadScreen;
