
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, ExternalLink, BookOpen, ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface ProcessingScreenProps {
  fileName: string;
  onReset: () => void;
}

/**
 * Tela de processamento e download dos resumos
 * Mostra animação de carregamento e após 5s exibe opções de download
 */
const ProcessingScreen: React.FC<ProcessingScreenProps> = ({ fileName, onReset }) => {
  const [progress, setProgress] = useState(0);
  const [showDownloads, setShowDownloads] = useState(false);
  const [processingStep, setProcessingStep] = useState('Analisando imagem...');

  const processingSteps = [
    'Analisando imagem...',
    'Extraindo informações do livro...',
    'Gerando resumo com IA...',
    'Preparando downloads...',
    'Concluído!'
  ];

  /**
   * Simula o progresso do processamento em 5 segundos
   */
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 2;
        
        // Atualiza o step baseado no progresso
        const stepIndex = Math.floor((newProgress / 100) * processingSteps.length);
        if (stepIndex < processingSteps.length) {
          setProcessingStep(processingSteps[stepIndex]);
        }
        
        // Após 5 segundos (100%), mostra os downloads
        if (newProgress >= 100) {
          clearInterval(interval);
          setTimeout(() => setShowDownloads(true), 500);
          return 100;
        }
        
        return newProgress;
      });
    }, 100); // Atualiza a cada 100ms para atingir 100% em 5s

    return () => clearInterval(interval);
  }, []);

  /**
   * Manipula cliques nos links de download
   */
  const handleDownloadClick = (type: 'md' | 'pdf' | 'notion') => {
    const urls = {
      // SUBSTITUIR LINKS DO N8N AQUI
      md: 'https://SEU_N8N_ENDPOINT/webhook/download-md',
      pdf: 'https://SEU_N8N_ENDPOINT/webhook/download-pdf',
      notion: 'https://notion.so/SEU_LINK_DE_DESTINO'
    };
    
    window.open(urls[type], '_blank');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header com informações do arquivo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <motion.div
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg"
          >
            <BookOpen className="w-8 h-8 text-white" />
          </motion.div>
          
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Processando Resumo
          </h2>
          <p className="text-gray-600">
            Arquivo: <span className="font-semibold text-blue-600">{fileName}</span>
          </p>
        </motion.div>

        {/* Card principal */}
        <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
          <CardContent className="p-8">
            {!showDownloads ? (
              /* Tela de carregamento */
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-8"
              >
                {/* Animação de processamento */}
                <div className="text-center space-y-6">
                  <motion.div
                    animate={{ 
                      scale: [1, 1.2, 1],
                      opacity: [0.7, 1, 0.7]
                    }}
                    transition={{ 
                      duration: 1.5, 
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="relative mx-auto w-24 h-24"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-600 rounded-full"></div>
                    <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center">
                      <Sparkles className="w-8 h-8 text-purple-600" />
                    </div>
                  </motion.div>
                  
                  <motion.p
                    key={processingStep}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-lg font-medium text-gray-700"
                  >
                    {processingStep}
                  </motion.p>
                </div>

                {/* Barra de progresso */}
                <div className="space-y-3">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Progresso</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                {/* Indicadores visuais de processamento */}
                <div className="grid grid-cols-3 gap-4">
                  {['Análise', 'IA Generativa', 'Formatação'].map((step, index) => (
                    <motion.div
                      key={step}
                      initial={{ opacity: 0.3 }}
                      animate={{ 
                        opacity: progress > (index + 1) * 33 ? 1 : 0.3,
                        scale: progress > (index + 1) * 33 ? 1.05 : 1
                      }}
                      className="text-center p-3 rounded-lg bg-gradient-to-br from-blue-50 to-purple-50"
                    >
                      <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center ${
                        progress > (index + 1) * 33 
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white' 
                          : 'bg-gray-200 text-gray-400'
                      }`}>
                        {index + 1}
                      </div>
                      <p className="text-xs font-medium text-gray-600">{step}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ) : (
              /* Tela de downloads */
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* Sucesso */}
                <div className="text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", duration: 0.6 }}
                    className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2 }}
                    >
                      ✅
                    </motion.div>
                  </motion.div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Resumo Concluído!
                  </h3>
                  <p className="text-gray-600">
                    Escolha o formato para baixar ou visualizar
                  </p>
                </div>

                {/* Opções de download */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">
                    Downloads Disponíveis:
                  </h4>
                  
                  {/* Markdown */}
                  <motion.div
                    whileHover={{ x: 5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button 
                      variant="outline" 
                      className="w-full justify-between p-6 h-auto border-2 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200"
                      onClick={() => handleDownloadClick('md')}
                    >
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                          <FileText className="w-6 h-6 text-blue-600" />
                        </div>
                        <div className="text-left">
                          <p className="font-semibold text-gray-900">Baixar como Markdown</p>
                          <p className="text-sm text-gray-500">Formato .md para edição</p>
                        </div>
                      </div>
                      <Download className="w-5 h-5 text-gray-400" />
                    </Button>
                  </motion.div>

                  {/* PDF */}
                  <motion.div
                    whileHover={{ x: 5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button 
                      variant="outline" 
                      className="w-full justify-between p-6 h-auto border-2 hover:border-red-300 hover:bg-red-50 transition-all duration-200"
                      onClick={() => handleDownloadClick('pdf')}
                    >
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                          <FileText className="w-6 h-6 text-red-600" />
                        </div>
                        <div className="text-left">
                          <p className="font-semibold text-gray-900">Baixar como PDF</p>
                          <p className="text-sm text-gray-500">Formato .pdf para leitura</p>
                        </div>
                      </div>
                      <Download className="w-5 h-5 text-gray-400" />
                    </Button>
                  </motion.div>

                  {/* Notion */}
                  <motion.div
                    whileHover={{ x: 5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button 
                      variant="outline" 
                      className="w-full justify-between p-6 h-auto border-2 hover:border-purple-300 hover:bg-purple-50 transition-all duration-200"
                      onClick={() => handleDownloadClick('notion')}
                    >
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                          <ExternalLink className="w-6 h-6 text-purple-600" />
                        </div>
                        <div className="text-left">
                          <p className="font-semibold text-gray-900">Ver no Notion</p>
                          <p className="text-sm text-gray-500">Abrir diretamente no workspace</p>
                        </div>
                      </div>
                      <ExternalLink className="w-5 h-5 text-gray-400" />
                    </Button>
                  </motion.div>
                </div>

                {/* Botão para processar outro livro */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="pt-6 border-t"
                >
                  <Button 
                    variant="ghost" 
                    onClick={onReset}
                    className="w-full text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Processar Outro Livro
                  </Button>
                </motion.div>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProcessingScreen;
