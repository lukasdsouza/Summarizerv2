
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import UploadScreen from '@/components/UploadScreen';
import ProcessingScreen from '@/components/ProcessingScreen';
import { useToast } from '@/hooks/use-toast';

/**
 * Componente principal do Summarizer
 * Gerencia o estado entre as telas de upload e processamento
 */
const Index = () => {
  const [currentScreen, setCurrentScreen] = useState<'upload' | 'processing'>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  /**
   * Manipula o upload da imagem para o endpoint do n8n
   * @param file - Arquivo de imagem selecionado pelo usuário
   */
  const handleFileUpload = async (file: File) => {
    try {
      const formData = new FormData();
      formData.append('data', file); // Nome do campo alterado para 'data' conforme especificado

      // Conectando com o endpoint do n8n fornecido
      const response = await fetch('https://olukasouza000000.app.n8n.cloud/webhook-test/upload-livro', {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json',
        },
      });

      if (response.ok) {
        setSelectedFile(file);
        setCurrentScreen('processing');
        toast({
          title: "Upload realizado com sucesso!",
          description: "Iniciando processamento do resumo...",
        });
      } else {
        throw new Error('Upload failed');
      }
    } catch (error) {
      console.error('Erro no upload:', error);
      toast({
        title: "Erro no upload",
        description: "Não foi possível enviar a imagem. Verifique sua conexão e tente novamente.",
        variant: "destructive",
      });
    }
  };

  /**
   * Retorna para a tela de upload
   */
  const handleReset = () => {
    setCurrentScreen('upload');
    setSelectedFile(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <AnimatePresence mode="wait">
        {currentScreen === 'upload' ? (
          <motion.div
            key="upload"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            <UploadScreen onFileUpload={handleFileUpload} />
          </motion.div>
        ) : (
          <motion.div
            key="processing"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            <ProcessingScreen 
              fileName={selectedFile?.name || ''} 
              onReset={handleReset}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Index;
